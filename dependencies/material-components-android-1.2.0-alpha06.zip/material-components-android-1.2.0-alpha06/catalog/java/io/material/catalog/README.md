# Catalog

The Android version of the Material Design Component Catalog, intended to demonstrate Material
Design principles and provide component demonstrations and code examples.
